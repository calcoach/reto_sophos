package com.sophos.utc.api.dto;

public class RoleDTO {
	private Long rol_id;

	public Long getRol_id() {
		return rol_id;
	}

	public void setRol_id(Long rol_id) {
		this.rol_id = rol_id;
	}
}
