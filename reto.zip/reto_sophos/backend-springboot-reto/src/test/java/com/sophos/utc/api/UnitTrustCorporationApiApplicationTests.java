package com.sophos.utc.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitTrustCorporationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
